package com.example.android.imageprocessing;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;

import java.io.ByteArrayOutputStream;

/**
 * Created by auliaamirullah on 19/12/17.
 */

public class TakePictureActivity extends AppCompatActivity {

    ImageView take_picture;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        take_picture = (ImageView) findViewById(R.id.take_picture);

        take_picture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentCamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intentCamera, 0);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        setContentView(R.layout.test);
        final Bitmap bitmap = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();

        Intent intent = new Intent(TakePictureActivity.this, ProcessActivity.class);
        intent.putExtra("bitmap", byteArray);
        startActivity(intent);
        //Toast.makeText(this, "Test Berhasil", Toast.LENGTH_SHORT).show();
    }

    //BaseLoaderCallBack harus digunakan ketika Menggunakan OpenCV
    BaseLoaderCallback baseLoaderCallback = new BaseLoaderCallback(this) {
        @Override
        public void onManagerConnected(int status) {
            switch (status){
                case LoaderCallbackInterface.SUCCESS :
                    //Toast.makeText(TakePictureActivity.this,"Opencv Berhasil DiLoad",Toast.LENGTH_SHORT).show();
                    break;
                default:
                    super.onManagerConnected(status);
                    break;
            }


        }
    };

    //Ketika Aplikasi OpenCV diResume
    @Override
    protected void onResume() {
        super.onResume();
        OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_3_1_0,this,baseLoaderCallback);

    }

}


