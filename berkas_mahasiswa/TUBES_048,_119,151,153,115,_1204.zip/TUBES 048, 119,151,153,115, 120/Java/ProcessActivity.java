package com.example.android.imageprocessing;

import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import org.opencv.android.Utils;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

/**
 * Created by auliaamirullah on 19/12/17.
 */

public class ProcessActivity extends AppCompatActivity {

    ImageView imageTampil;
    LinearLayout gaussian;
    LinearLayout canny;
    LinearLayout hough;
    LinearLayout adaptive;

    Bitmap bitmap;
    Bitmap resultBitmap;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.process_activity);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
//        getActionBar().setDisplayHomeAsUpEnabled(true);


        byte[] byteArray = getIntent().getByteArrayExtra("bitmap");
        bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);

        imageTampil = (ImageView) findViewById(R.id.imageTampil);
        gaussian = (LinearLayout) findViewById(R.id.gaussian);
        canny = (LinearLayout) findViewById(R.id.canny);
        hough = (LinearLayout) findViewById(R.id.hough);
        adaptive = (LinearLayout) findViewById(R.id.adaptive);

        imageTampil.setImageBitmap(bitmap);

        gaussian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setGaussian(bitmap);
            }
        });

        canny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setCanny(bitmap);
            }
        });

        hough.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setHough(bitmap);
            }
        });

        adaptive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAdaptive(bitmap);
            }
        });

    }

    private  void simpan()
    {
        BitmapDrawable bd = (BitmapDrawable) imageTampil.getDrawable();
        Bitmap b = bd.getBitmap();
        try {
            MediaStore.Images.Media.insertImage(this.getContentResolver(), b, "title", "desc");
            Toast.makeText(this, "Berhasil Disimpan", Toast.LENGTH_SHORT).show();
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void setCanny(Bitmap bitmaps)
    {
        //1.Read The Bitmap

        //2.Convert From Bitmap to Mat
        Mat rgba = new Mat();
        Utils.bitmapToMat(bitmap, rgba);

        //3. Make an array dimana Hasil Pemrosesan akan disimpan di dalam Array
        Mat edges = new Mat(rgba.size(), CvType.CV_8UC1);

        //4.Convert To GrayScale
        Imgproc.cvtColor(rgba, edges, Imgproc.COLOR_RGB2GRAY, 4);

        //5.Aplikasikan Canny Algorithm , Parameter :
        //a.Mat image : 8 bit input
        //b.Mat edges – output edge map; single channels 8-bit image, which has the same size as image
        //c.double treshold1– first threshold for the hysteresis procedure
        //d.dobule treshold2– second threshold for the hysteresis procedure
        Imgproc.Canny(edges, edges, 80, 100);

        //6.Tampilkan Gambar Originial dan Yang Sudah Diconvert , Gambar Yang sudah diconvert harus di
        //Ubah dulu menjadi Mat To Bitmap
        // Don't do that at home or work it's for visualization purpose.

        resultBitmap = Bitmap.createBitmap(edges.cols(), edges.rows(), Bitmap.Config.ARGB_8888);
        Utils.matToBitmap(edges, resultBitmap);

//        BitmapHelper.showBitmap(this, resultBit/map, imageTampil);
        imageTampil.setImageBitmap(resultBitmap);


    }

    public void setGaussian(Bitmap bitmaps) {
        //code
        //1.Read The Bitmap

        //2.Convert From Bitmap to Mat
        Mat dest = new Mat();
        Mat source = new Mat();
        Utils. bitmapToMat( bitmap, source);
//        //3. Make an array dimana Hasil Pemrosesan akan disimpan di dalam Array
//        Mat edges = new Mat(rgba.size(), CvType.CV_8UC1);
//
//        //4.Convert To GrayScale
//        Imgproc.cvtColor(rgba, edges, Imgproc.COLOR_RGB2GRAY, 4);

        Imgproc.GaussianBlur(source, dest, new Size(45,45), 0);

        resultBitmap = Bitmap.createBitmap(dest.cols(), dest.rows(), Bitmap.Config.ARGB_8888);
        Utils.matToBitmap(dest, resultBitmap);

//        BitmapHelper.showBitmap(this, resultBit/map, imageTampil);
        imageTampil.setImageBitmap(resultBitmap);

    }

    public void setHough(Bitmap bitmaps)
    {

        //1.Read The Bitmap


        Mat dest = new Mat();
        Mat source = new Mat();

        Utils. bitmapToMat(bitmap, source);


        Mat gray = new Mat();
        Imgproc.cvtColor(source, gray, Imgproc.COLOR_BGR2GRAY);
        Imgproc.medianBlur(gray, gray, 5);

        Mat circles = new Mat();
        Imgproc.HoughCircles(gray, circles, Imgproc.HOUGH_GRADIENT, 1.0,
                (double)gray.rows()/16, // change this value to detect circles with different distances to each other
                100.0, 30.0, 1, 30); // change the last two parameters
        // (min_radius & max_radius) to detect larger circles

        // (min_radius & max_radius) to detect larger circles
        for (int x = 0; x < circles.cols(); x++) {
            double[] c = circles.get(0, x);
            Point center = new Point(Math.round(c[0]), Math.round(c[1]));
            // circle center
            Imgproc.circle(source, center, 1, new Scalar(0,100,100), 3, 8, 0 );
            // circle outline
            int radius = (int) Math.round(c[2]);
            Imgproc.circle(source, center, radius, new Scalar(255,0,255), 3, 8, 0 );
        }
        dest = source;

        resultBitmap = Bitmap.createBitmap(dest.cols(), dest.rows(), Bitmap.Config.ARGB_8888);
        Utils.matToBitmap(dest, resultBitmap);

//        BitmapHelper.showBitmap(this, resultBit/map, imageTampil);
        imageTampil.setImageBitmap(resultBitmap);

    }

    public void setAdaptive(Bitmap bitmaps)
    {
        Mat dest = new Mat();
        Mat source = new Mat();
        Utils. bitmapToMat( bitmap, source);

        Mat gray = new Mat();
        Imgproc.cvtColor(source, gray, Imgproc.COLOR_BGR2GRAY);
        Imgproc.medianBlur(gray, gray, 5);
        Imgproc.adaptiveThreshold(gray, dest, 255, Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C, Imgproc.THRESH_BINARY,11,2);

        resultBitmap = Bitmap.createBitmap(dest.cols(), dest.rows(), Bitmap.Config.ARGB_8888);
        Utils.matToBitmap(dest, resultBitmap);

//        BitmapHelper.showBitmap(this, resultBit/map, imageTampil);
        imageTampil.setImageBitmap(resultBitmap);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.save:
                simpan();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
